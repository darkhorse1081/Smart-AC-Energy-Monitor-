/*
 * main.c
 *
 * Created: 16/08/2024 4:48:24 pm
 * Author : TEAM TECH TITANS TWO
 *
 * The aim of this project is to display the power dissipated by a source voltage 14 Vrms +- 10%
 * 500Hz +- 2% when a load of the range 2.5 VA to 7.5 VA is attached to it.
 *
 * Some important information:
 *		- ADC Conversion Rate = 10kHz or slower
 *		- LCD Display Information: Voltage (Vrms), Peak Current (mA) and Power (W)
 *		- LCD Scroll Rate = 1s
 *		- UART Specifications: 9600 Baud, 8N1 with no parity
 *		- Information Transferred via UART: Voltage, Peak Current, Power and Energy
 */ 
#define F_CPU 2000000UL // 2MHz CPU clock
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "common.h"
#include "uart.h"
#include "display.h"
#include "timer0.h"
#include "adc.h"
#include "interrupts.h"

volatile uint16_t number = 0;
volatile uint8_t sample = 0;

volatile extern uint16_t voltage_samples_1[20];
volatile extern uint16_t current_samples_1[20];
volatile extern uint16_t voltage_samples_2[20];
volatile extern uint16_t current_samples_2[20];
volatile extern uint16_t voltage_samples[40];
int main(void)
{	
	uart_init(BAUD_RATE);
	display_init();
	adc_init();
	timer0_init();
	int0_init(); 
    while (1) 
    {
		_delay_ms(1000);
		
		sei();
		while (sample != 20) {}
		timer0_stop();
		cli();
		
		EIMSK |= (1 << INT0);
		sei();
		while (sample != 40) {}
		timer0_stop();
		cli();
		
		
		for (uint8_t i = 0; i < 20; i++) {
			transmit_large_number(convert_adc_to_voltage(voltage_samples_1[i]));
			transmit_comma();
			transmit_large_number(convert_adc_to_voltage(voltage_samples_2[i]));
			transmit_newline();
		}
// 		uint8_t j = 0;
// 		uint8_t k = 0;
// 		for (uint8_t i = 0; i < 40; i++) {
// 			if (i%2==0) {
// 				voltage_samples[i] = voltage_samples_1[j];
// 				j++;
// 			} else {
// 				voltage_samples[i] = voltage_samples_2[k];
// 				k++;
// 			}
// 		}
		
// 		for (uint8_t i = 1; i < 39; i++) {
// 			transmit_large_number(convert_adc_to_voltage(voltage_samples[i]));
// 			transmit_newline();
// 		}
		while (1) {}
	}
}

