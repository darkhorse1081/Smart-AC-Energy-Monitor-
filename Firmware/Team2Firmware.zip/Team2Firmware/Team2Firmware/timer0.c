/*
 * timer0.c
 *
 * Created: 22/09/2024 4:00:04 pm
 *  Author: ryane
 */ 
#include <avr/io.h>
#include <avr/interrupt.h>

#include "timer0.h"
#include "adc.h"
#include "uart.h"

volatile extern uint16_t number;
volatile uint8_t decimal_pos = 0;

ISR(TIMER0_COMPA_vect) {
}

void timer0_init() {
	TCCR0A |= (1 << WGM01);				// Clear on compare match with ocr0a
	OCR0A = 212;						// Sets counter for timer to reset = 104us 
	TIMSK0 |= (1 << OCIE0A);			// Enables interrupts
}

void timer0_start_0prescaler() {
	TCNT0 = 0x00;
	TCCR0B |= (1 << CS00);				// I/O Clock prescaler == 0, => resolution = 0.5us
}

void timer0_stop() {
	TCCR0B &= ~((7 << CS00));
}
/* Tasks:
    Use timer to
   . measure current and voltage signals 
   . measure the time between zero crossings, to find the frequency
   . update display and send data over UART periodically
*/
