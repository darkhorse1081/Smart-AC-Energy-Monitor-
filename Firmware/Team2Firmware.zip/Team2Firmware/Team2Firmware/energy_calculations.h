/*
 * energy_calculations.h
 *
 * Created: 22/09/2024 3:58:58 pm
 *  Author: ryane
 */ 


#ifndef ENERGY_CALCULATIONS_H_ 
#define ENERGY_CALCULATIONS_H_ 

// These need to be checked
#define G_vo 1
#define G_vs 11
#define G_is 1
#define G_io 1
#define V_off 1

uint8_t find_ac_voltage(uint8_t V_vf);
uint8_t find_load_current(uint8_t V_if);
void conversion_to_ac_voltage(uint8_t values[40], uint8_t result[40]);
void conversion_to_load_current(uint8_t values[40], uint8_t result[40]);
uint8_t get_rms(uint8_t values[40]);

uint8_t power(uint8_t voltage_ac[40], uint8_t load_current[40]);

#endif /* ENERGY_CALCULATIONS_H_ */