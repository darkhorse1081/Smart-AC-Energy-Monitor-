/*
*	Energy Calculations:
*		- Power
*		- Energy
*
*	If ADC is set to capture a sample every 0.1ms (10kHz).
*
* Ryan's thoughts: I want to do the separate sampling/quantization.
*	This means that we sample one full wave of voltages and then what
*	we would normally do is sample one full wave of currents afterwards.
*   But what I want to do is complete the voltage sampling and post that,
*   we set a wait time of exactly half the normal ADC sampling process
*	and then we start ADC sampling again. This means we would have captured
*	two waves at different intervals, thus when we superimpose them we will
*	have a single wave with double the resolution. Now, we could do this with
*	different wait times and thus make even better resolution. After we capture
*	the voltage wave... we would capture the current wave. This does require
*	the assumption that both waves are identical to each other.
*/

#include <avr/io.h>

#include "energy_calculations.h"

uint16_t voltage_samples_1[20]; // These will be the sampled values
uint16_t current_samples_1[20]; // These will be the sampled values
uint16_t voltage_samples_2[20];
uint16_t current_samples_2[20];

uint16_t voltage_samples[40]; // Joined.

uint32_t voltage_values[40];	// Converted values
uint32_t current_values[40];	// Converted values

uint16_t voltage_rms = 0; // rms values
uint16_t current_rms = 0; // rms values
/*
* Voltage Measurement:
*
* G_vs: Step down voltage achieved by voltage divider
* G_vo: Differential amplification
* V_off: offset
*
* V_vf = G_vs * G_vo * V_AC + V_off
*
* Since this is the input of the signal, we need to rearrange in order
* to find the V_rms of the original V_AC.
*
* V_AC = (V_vf - V_off) / (G_vs * G_vo)
*/
uint8_t find_ac_voltage(uint8_t V_vf) {
	return (V_vf - V_off) / (G_vs * G_vo);
}

/*
* Current Measurement:
* 
* G_is: shunt resistor
* G_io: differential amplification
* V_off: offset
*
* V_if = G_is * G_io * I_L + V_off
*
* Since this is the input signal we need to rearrange in order
* to find I_L (A).
*
* I_L = (V_if - V_off) / (G_is * G_io)
*/
uint8_t find_load_current(uint8_t V_if) {
	return (V_if - V_off) / (G_is * G_io);
}


/*
*	So for reference we would have an array of many voltage values
*	Each of these values would need to be passed through the above
*	equations in order to be converted into their predictive V_AC/I_L
*	values.
*
*/

void conversion_to_ac_voltage(uint8_t values[40], uint8_t result[40]) {
	for (uint8_t i = 0; i < 40; i++) {
		result[i] = find_ac_voltage(values[i]);
	}
}

void conversion_to_load_current(uint8_t values[40], uint8_t result[40]) {
	for (uint8_t i = 0; i < 40; i++) {
		result[i] = find_load_current(values[i]);
	}
}

/* Since we are not using a dedicated circuit to work out the peak values
*  we will be estimating the values using the following formulas.
*
*  V_AC_rms = sqrt(1/T_p * integral(V_AC^2 dt, [T_p,0])
*
*  I_L_rms = sqrt(1/T_p * intergral(I_L^2 dt, [T_p, 0])
*
*  Since we cannot sample and store a continuous wave, we must revert to using
*  discrete value to estimate the above quantities. We can do this using the
*  Riemann sum.
*
*  If we have taken N ADC samples at regular (delta)t_sample intervals over
*  one time period of the signal, the time period T_p = N(delta)t_sample
*
*  V_AC_rms^2 = (1 /(N * (delta)t_sample)) * sum(V_AC^2[i] * (delta)t_sample, [for i in range(N-1)])
*  I_L_rms^2 = (1 /(N * (delta)t_sample)) * sum(I_L^2[i] * (delta)t_sample, [for i in range(N-1)])
*
*/

uint8_t get_rms(uint8_t values[40]) {
	
	uint8_t n = 40; 
	uint8_t t_sample = 0; // very small value... will need to do integer calculations
	uint8_t total = 0;
	
	for (uint8_t i = 0; i < 40; i++) {
		total += (values[i] ^ 2) * t_sample;
	}
	
	return (1 / (n * t_sample)) * total;
}

/*
* We will need to do something with the comparators
*/

/*
*  Estimating Power Using RMSs
*
*  P = (1 / N) * sum(V_AC[i] * I_L[i], [i=0,N-1])
*
*/

uint8_t power(uint8_t voltage_ac[40], uint8_t load_current[40]) {
	
	uint8_t total = 0;
	uint8_t n = 40;
	
	for (uint8_t i = 0; i < 40; i++) {
		total += voltage_ac[i] * load_current[i];
	}
	
	return (1 / n) * total;
}

