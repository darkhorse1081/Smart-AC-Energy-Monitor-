/*
 * interrupts.c
 *
 * Created: 22/09/2024 4:16:05 pm
 *  Author: ryane
 */ 
#define F_CPU 2000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "interrupts.h"
#include "timer0.h"

volatile extern uint8_t sample;

ISR(INT0_vect) {
// 	if (sample == 20) {
// 		_delay_us(25);
// 	}
	timer0_start_0prescaler();
	EIMSK &= ~(1 << INT0);
}

void int0_init() {
	EICRA |= ((1 << ISC00) | (1 << ISC01));		// Rising edge
	EIMSK |= (1 << INT0);						// Enables interrupt
}

void int1_init() {
	EICRA &= ~(1 << ISC11);						// Clears
	EICRA |= ((1 << ISC10) | (1 << ISC00));		// On rising edge
	EIMSK |= (1 << INT1);						// Enables interrupt
}