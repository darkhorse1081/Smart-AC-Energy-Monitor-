/*
*	Author: TEAM TECH TITANS TWO
*
*	This file is for the functions to implement the timer 1 processes.
*/