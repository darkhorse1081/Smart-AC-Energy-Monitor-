/*
 * adc.h
 *
 * Created: 22/09/2024 3:58:15 pm
 *  Author: ryane
 */ 


#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>


#define AVCC (1 << REFS0)
#define VOLTAGE_SIGNAL (1 << PORTC0)
#define CURRENT_SIGNAL (1 << PORTC1)

#define RESOLUTION 4880 //uV

void adc_init();
uint16_t adc_read();
void adc_set_channel(uint8_t channel);

void get_voltage_samples_1();
void get_current_samples_1();

void get_voltage_samples_2();
void get_current_samples_2();

uint16_t convert_adc_to_voltage(uint16_t value);

#endif /* ADC_H_ */