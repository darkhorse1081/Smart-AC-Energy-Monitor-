/*
*	Author: TEAM TECH TITANS TWO
*
*	This file is for the functions to implement the UART processes.
*/
#include <avr/io.h>
#include "uart.h"

void uart_init(uint16_t ubrr) {
	UCSR0B |= TRANSMIT_ENABLE;
	UCSR0C |= EIGHTN1;
	UBRR0 = ubrr;						// Baud Rate Value
}

void uart_transmission(uint8_t data) {
	while (UDR0_IS_NOT_READY) { }			// Waits until UDR0 is ready before setting new data to be sent
	UDR0 = data;						// Sets new data to be sent
}

void transmit_number(uint8_t data) { // Transmits single digit
	uart_transmission(data + 48);
}

void transmit_comma() { 
	uart_transmission(44);
}

void transmit_newline() {
	uart_transmission(13); // Windows new line
	uart_transmission(10); // Mac and Linux new line
}

void transmit_dp() {
	uart_transmission(46); // Transmit decimal point
}

void transmit_large_number(uint16_t num) { // Transmit up to 6 digit number
	if (num == 0) {
		transmit_number(0);
		return;
	}

	uint8_t buffer[6];
	for (int8_t i = 0; i < 6; i++) {
		buffer[i] = num % 10;
		num /= 10;
	}
	for (int8_t i = 5; i >= 0; i--) {
		transmit_number(buffer[i]);
	}
}


